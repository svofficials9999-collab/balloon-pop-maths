/* Compatibility for clients still controlled by the previous worker. */
if(typeof Audio==='function'&&window.__AKNBinary?.version!==2){(()=>{'use strict';
 const Native=window.Audio,pending=new Map(),groups=new Map();
 const binary=s=>{try{const u=new URL(s,document.baseURI);return (u.origin===location.origin||u.origin==='https://aksharanova-lesson-audio-01.pages.dev')&&/\/learn\/audio\/media\/[a-f0-9]{64}\.(ogg|mp3|wav)$/.test(u.pathname)}catch(e){return false}};
 const bytes=u=>{if(!pending.has(u))pending.set(u,(async()=>{const c=await caches.open('akn-audio-binary-v1');let r=await c.match(u);if(!r){r=await fetch(u,{referrerPolicy:'no-referrer'});if(!r.ok||r.status!==200)throw Error('Recording unavailable');await c.put(u,r.clone())}return r.blob()})());return pending.get(u)};
 function register(urls){urls=[...new Set(urls.filter(binary))];if(!urls.length)return;const fresh=urls.filter(u=>!groups.has(u));if(!fresh.length)return;const p=Promise.all(fresh.map(bytes)).then(()=>{});for(const u of fresh)groups.set(u,p);p.then(()=>{for(const u of fresh)pending.delete(u)},()=>{for(const u of fresh){pending.delete(u);groups.delete(u)}});}
 function BinaryAudio(src){if(!binary(src))return new Native(src);const a=new Native(),play=a.play.bind(a),pause=a.pause.bind(a),load=a.load.bind(a);let wanted=false,attempt=0;
 const item=bytes(src),ready=Promise.all([groups.get(src)||Promise.resolve(),item]).then(v=>new Promise((ok,bad)=>{const reader=new FileReader();reader.onload=()=>{const rate=a.playbackRate;a.src=reader.result;a.playbackRate=rate;ok()};reader.onerror=bad;reader.readAsDataURL(v[1])}));
 ready.catch(()=>a.dispatchEvent(new Event('error')));a.play=()=>{wanted=true;const n=++attempt;return ready.then(()=>wanted&&n===attempt?play():undefined)};a.pause=()=>{wanted=false;++attempt;pause()};a.load=()=>{ready.then(()=>{const rate=a.playbackRate;load();a.playbackRate=rate},()=>{})};return a;
 }
 BinaryAudio.prototype=Native.prototype;Object.setPrototypeOf(BinaryAudio,Native);window.Audio=BinaryAudio;window.__AKNBinary={register,version:2};
})();}
