#!/usr/bin/env python3
"""Transform a completed static Pages build; never edit repository source audio."""
import argparse,base64,hashlib,json,pathlib,re,shutil,subprocess,tempfile

def prepare(site, ceiling=950000000):
    kit=pathlib.Path(__file__).resolve().parent
    prefix=(kit/'audio-adapter.js').read_text()
    prefix_v2=(kit/'audio-adapter-v2.js').read_text()
    retained=set(json.loads((kit/'retained-media-sha256.json').read_text()))
    remote_origin='https://aksharanova-lesson-audio-01.pages.dev'
    remote_verified=set()
    recordings=site/'learn/audio'; media=recordings/'media'; media.mkdir(exist_ok=True)
    indices=['learn/audio/index.json','learn/audio/index_m.json','learn/br/index.json','learn/br/index_m.json']
    original_indices={p:(site/p).read_bytes() for p in indices}
    changed=[]; clips=[]; old_bytes=0; wrapper_bytes=0
    pattern=re.compile(r"[\"']data:(audio/[^\"'\r\n]+?);base64,([A-Za-z0-9+/=]+)[\"']")
    for p in sorted(recordings.glob('*.js')):
        original=p.read_bytes();text=original.decode();found=[];external=[]
        def replace(m):
            raw=base64.b64decode(m.group(2),validate=True);digest=hashlib.sha256(raw).hexdigest()
            mime=m.group(1);ext='ogg' if 'ogg' in mime else 'mp3' if 'mpeg' in mime else 'wav' if 'wav' in mime else None
            if not ext: raise ValueError('Unsupported media type '+mime)
            path=media/(digest+'.'+ext)
            if digest not in retained:
                url=remote_origin+'/learn/audio/media/'+digest+'.'+ext
                if url not in remote_verified:
                    with tempfile.TemporaryDirectory() as temp:
                        dest=pathlib.Path(temp)/'audio';headers=pathlib.Path(temp)/'headers'
                        subprocess.run(['curl','--fail','--silent','--show-error','--location','--max-time','45','--dump-header',str(headers),'--output',str(dest),url],check=True)
                        assert 'access-control-allow-origin: https://svofficials9999-collab.github.io' in headers.read_text().lower(),'Remote CORS mismatch'
                        assert hashlib.sha256(dest.read_bytes()).hexdigest()==digest,'Remote recording bytes differ'
                    remote_verified.add(url)
                found.append({'sha256':digest,'bytes':len(raw),'path':url,'external':True})
                external.append(url)
                return json.dumps(url)
            if path.exists(): assert path.read_bytes()==raw
            else:path.write_bytes(raw)
            assert hashlib.sha256(path.read_bytes()).hexdigest()==digest
            found.append({'sha256':digest,'bytes':len(raw),'path':str(path.relative_to(site))})
            return 'new URL('+json.dumps('./media/'+digest+'.'+ext)+',document.currentScript.src).href'
        output=pattern.sub(replace,text)
        if not found:raise ValueError('Shard has no convertible recordings: '+str(p))
        if 'data:audio/' in output:raise ValueError('Unconverted audio in '+str(p))
        output=(prefix_v2 if external else prefix)+output+'\nif(window.__AKNBinary)window.__AKNBinary.register(Object.values(window.__AUD));\n'
        p.write_text(output);old_bytes+=len(original);wrapper_bytes+=len(output.encode());changed.append(str(p.relative_to(site)));clips.extend(found)
    shutil.copyfile(kit/'audio-range.js',site/'audio-range.js')
    # Fail closed if the known worker layout has changed, rather than editing
    # unknown code or silently skipping its range handler.
    for relative,imp,old,new in [('sw.js',"importScripts('./audio-range.js');\n",'4.15.199-roadPractice','4.15.200-audioBinary'),('gkdaily/sw.js',"importScripts('../audio-range.js');\n",'akn-gkdaily-41','akn-gkdaily-42-audioBinary')]:
        p=site/relative;text=p.read_text();anchor="self.addEventListener('fetch',e=>{"
        if text.count(anchor)!=1 or old not in text:raise ValueError('Worker source changed: '+relative)
        p.write_text(imp+text.replace(anchor,anchor+'if(akAudioRequest(e))return;').replace(old,new))
    for p,data in original_indices.items():assert (site/p).read_bytes()==data
    total=sum(p.stat().st_size for p in site.rglob('*') if p.is_file())
    if total>=ceiling:raise ValueError('Static output exceeds ceiling: '+str(total))
    result={'changed_shards':len(changed),'embedded_occurrences':len(clips),'unique_media_files':len(set(x['path'] for x in clips)),'old_shard_bytes':old_bytes,'replacement_wrapper_bytes':wrapper_bytes,'output_content_bytes':total,'ceiling_bytes':ceiling,'unchanged_indices':indices,'changed_paths':changed+['sw.js','gkdaily/sw.js'],'added_paths':sorted(set(x['path'] for x in clips))+['audio-range.js'],'clips':clips,'remote_origin':remote_origin,'verified_remote_assets':sorted(remote_verified)}
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--site',type=pathlib.Path,required=True);parser.add_argument('--report',type=pathlib.Path,required=True);args=parser.parse_args();result=prepare(args.site);args.report.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['changed_paths','added_paths','clips']},indent=2))
