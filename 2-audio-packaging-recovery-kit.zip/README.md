# Same-site recording packaging repair

Status: local staging only. No remote repository or Pages-source change is authorized by this kit.

The transform runs AFTER the normal static/Jekyll build. It replaces embedded base64 payloads with byte-identical content-addressed files in the published output, leaving original source audio and all four index maps unchanged. Do not run it over an already transformed output.

Run:

    python3 prepare_audio.py --site PATH_TO_COMPLETED_STATIC_BUILD --report REPORT.json

Current measured baseline is repository commit 0c6bf4fdf81159531217c90acb882620cb3026e7. The worker transformation fails closed if its known fetch-handler/version anchors changed. Review and update anchors deliberately for newer source revisions.

Mandatory gates before publication:

- Evaluate all original and transformed shards in isolated JavaScript contexts. Compare per-shard ID sets and every decoded recording byte, not just file counts.
- Assert all four index maps remain byte-identical.
- Require both output content and final tar under 950,000,000 bytes. Measure the actual CI artifact, not compressed ZIP size.
- Test existing and updated root/GK workers; Opus and MP3; cancellation during load, playback speed, seek, end events; old cached dataURI migration; unplayed sibling recordings offline.
- Test representative recording families and full app regression independently. This kit does not certify speech content of new recordings.
- Keep an under-cap rollback output with the same binaries/adapter and working workers, last-good dated content, and later cache versions. A full original source-output revert is oversized and is not a usable deployment rollback.
- A GitHub Actions publishing-source change is a separate reviewed setting change. Do not silently enable it or trigger deployment.

No audio is trimmed, transcoded, relabeled, or removed. The adapter reconstructs native dataURI playback at runtime so clients controlled by older workers do not hit the older worker's partial-response cache bug. It preloads all sibling recordings and caches them using full 200 responses. Nonmatching Audio sources remain native.

Known limits: local tests use Chromium, not iOS Safari; live GitHub deployment and cross-browser checks remain separate gates. Browser storage quota and first-time offline misses behave as availability failures, not fabricated readiness. A successful decode is not speech-content verification.
