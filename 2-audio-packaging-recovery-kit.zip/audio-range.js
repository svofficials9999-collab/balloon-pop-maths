/* Byte-identical recording assets. Shared by root and daily GK workers. */
'use strict';
const AK_AUDIO_CACHE='akn-audio-binary-v1';
const AK_AUDIO_ROOT=new URL('./learn/audio/',self.registration.scope.includes('/gkdaily/')?new URL('../',self.registration.scope):self.registration.scope).href;
const AK_AUDIO_JOBS=new Map();
async function akFull(url){
 const cache=await caches.open(AK_AUDIO_CACHE),hit=await cache.match(url);
 if(hit&&hit.status===200)return hit;
 if(!AK_AUDIO_JOBS.has(url))AK_AUDIO_JOBS.set(url,(async()=>{const r=await fetch(url,{cache:'no-store'});if(!r.ok||r.status!==200)throw Error('Recording unavailable');await cache.put(url,r.clone());return r;})().finally(()=>AK_AUDIO_JOBS.delete(url)));
 return (await AK_AUDIO_JOBS.get(url)).clone();
}
async function akRange(request){
 const r=await akFull(request.url),range=request.headers.get('range');if(!range)return r;
 const bytes=await r.arrayBuffer(),size=bytes.byteLength,m=/^bytes=(\d*)-(\d*)$/.exec(range.trim());
 if(!m||(!m[1]&&!m[2]))return new Response(null,{status:416,headers:{'Content-Range':'bytes */'+size}});
 let start=m[1]?Number(m[1]):Math.max(0,size-Number(m[2])),end=m[1]?(m[2]?Math.min(Number(m[2]),size-1):size-1):size-1;
 if(start>=size||end<start||!Number.isSafeInteger(start)||!Number.isSafeInteger(end))return new Response(null,{status:416,headers:{'Content-Range':'bytes */'+size}});
 const h=new Headers(r.headers);h.set('Content-Range',`bytes ${start}-${end}/${size}`);h.set('Accept-Ranges','bytes');h.set('Content-Length',String(end-start+1));h.delete('Content-Encoding');return new Response(bytes.slice(start,end+1),{status:206,headers:h});
}
async function akShard(request){
 const cache=await caches.open(AK_AUDIO_CACHE);let r;
 try{r=await fetch(request,{cache:'no-store'});if(!r.ok)throw Error('Shard unavailable');}catch(e){r=await caches.match(request,{ignoreSearch:true});if(!r)throw e;}
 const text=await r.clone().text(),paths=[...text.matchAll(/\.\/media\/[a-f0-9]{64}\.(?:ogg|mp3|wav)/g)].map(m=>new URL(m[0],request.url).href);
 // Original shards contained every sibling recording. Warm all siblings before
 // releasing this replacement script so a cached shard keeps that behavior.
 for(let i=0;i<paths.length;i+=4)await Promise.all(paths.slice(i,i+4).map(akFull));
 await cache.put(request,r.clone());return r;
}
function akAudioRequest(e){
 const u=new URL(e.request.url);if(e.request.method!=='GET'||!u.href.startsWith(AK_AUDIO_ROOT))return false;
 if(u.pathname.includes('/media/')&&/\.(ogg|mp3|wav)$/.test(u.pathname)){e.respondWith(akRange(e.request));return true;}
 if(/\/(?!index(?:_m)?\.json)[^/]+\.js$/.test(u.pathname)){e.respondWith(akShard(e.request));return true;}
 return false;
}
